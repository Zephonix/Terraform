import json, boto3,os, sys, uuid
from urllib.parse import unquote_plus

s3_client = boto3.client('s3')

def lambda_handler(event, context):
    some_text = "test"
    #put the bucket name you create in step 1
    bucket_name = "zephonixbucket"
    file_name = "my_test_file.csv"
    lambda_path = "/tmp/" + file_name
    s3_path = "output/" + file_name
    os.system('echo testing... >'+lambda_path)
    s3 = boto3.resource("s3")
    s3.meta.client.upload_file(lambda_path, bucket_name, file_name)

    return {
        'statusCode': 200,
        'body': json.dumps('file is created in:'+s3_path)
    }
    
"""
import json
import boto3

s3 = boto3.client('s3')

def lambda_handler(event, context):
	bucket ='aws-simplified-transactions'

	transactionToUpload = {}
	transactionToUpload['transactionId'] = '12345'
	transactionToUpload['type'] = 'PURCHASE'
	transactionToUpload['amount'] = 20
	transactionToUpload['customerId'] = 'CID-11111'

	fileName = 'CID-11111' + '.json'

	uploadByteStream = bytes(json.dumps(transactionToUpload).encode('UTF-8'))

	s3.put_object(Bucket=bucket, Key=fileName, Body=uploadByteStream)

	print('Put Complete')
"""